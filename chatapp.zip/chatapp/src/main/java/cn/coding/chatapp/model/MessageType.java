package cn.coding.chatapp.model;

public enum MessageType {

    CHAT,CONNECT,DISCONNECT
}
