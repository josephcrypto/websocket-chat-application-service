package cn.coding.chatapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatmessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatmessageApplication.class, args);
	}

}
