package cn.coding.chatapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatmessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
